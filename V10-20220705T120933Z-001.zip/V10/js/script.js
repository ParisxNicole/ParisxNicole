/* this is a javascript comment */

console.log('hello class');
